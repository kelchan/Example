var childHeight = 55
function displayIfChildIsAbleToRideTheRollerCoaster () {
    if (childHeight > 52) {
        console.log("Get on that ride, kiddo!")
    }
    else {
        console.log("sorry kiddo. Maybe next year.")
    }
}